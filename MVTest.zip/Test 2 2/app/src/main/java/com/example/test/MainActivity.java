package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private Button recommendButton;
    private Button trendingButton;
    private Button lunchButton;
    private Button dinnerButton;
    private TextView userGreetings;
    private String username;


    public static final String SETOPDONE = "setupDone";
    public static final String NAMEUSER = "nameUser";
    private static final String OPEN_WEATHER_MAP_URL = "http://api.openweathermap.org/data/2.5/weather?lat=%s&lon=%s&units=metric";
    private static final String OPEN_WEATHER_MAP_API = "d102ff71f43e96421579ff1ac16c02bb";
    private TextView temperature;
    private ImageView weatherIC;
    static String latitude;
    static String longtitude;

    private boolean done;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadData();
        if (!done) {
            showSetup();
        } else if (done) {
            setContentView(R.layout.activity_main);
            BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

            bottomNavigationView.setSelectedItemId(R.id.nav_home);

            bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    switch (menuItem.getItemId()) {
                        case R.id.nav_recipe:
                            startActivity(new Intent(getApplicationContext()
                                    ,Recipe.class));
                            overridePendingTransition(0, 0);
                            return true;
                        case R.id.nav_calorie:
                            startActivity(new Intent(getApplicationContext()
                                    ,Calorie.class));
                            overridePendingTransition(0, 0);
                            return true;
                        case R.id.nav_exercise:
                            startActivity(new Intent(getApplicationContext()
                                    ,Exercise.class));
                            overridePendingTransition(0, 0);
                            return true;
                        case R.id.nav_profile:
                            startActivity(new Intent(getApplicationContext()
                                    ,Profile.class));
                            overridePendingTransition(0, 0);
                            return true;
                        case R.id.nav_home:
                            return true;
                    }
                    return false;
                }
            });

            userGreetings = findViewById(R.id.text_greeting_home);
            Calendar calendar = Calendar.getInstance();
            int timeofDay = calendar.get(Calendar.HOUR_OF_DAY);
            if(timeofDay >= 0 && timeofDay <12){
                userGreetings.setText("Good Morning, " + username);
            }
            else if(timeofDay >=12 && timeofDay <16){
                userGreetings.setText("Good Afternoon, " + username);
            }
            else if(timeofDay >=16 && timeofDay <21){
                userGreetings.setText("Good Evening, " + username);
            }
            else if(timeofDay >=21 && timeofDay <24){
                userGreetings.setText("Good Night, " + username);
            }
            recommendButton = (Button) findViewById(R.id.button_recommended_home);
            trendingButton = (Button) findViewById(R.id.button_trending_home);
            lunchButton = (Button) findViewById(R.id.button_lunch_home);
            dinnerButton = (Button) findViewById(R.id.button_dinner_home);

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            requestPermissions();

            FusedLocationProviderClient mFusedLocationProviderClient;
            mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
            if(ActivityCompat.checkSelfPermission(MainActivity.this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            mFusedLocationProviderClient.getLastLocation().addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    latitude = String.valueOf(location.getLatitude());
                    longtitude = String.valueOf(location.getLongitude());

                    temperature = (TextView) findViewById(R.id.text_temperature);
                    weatherIC = (ImageView) findViewById(R.id.image_weather);
                    String[] jsonData = getJSONResponse();

//                    temperature.setText(jsonData[1]);
                    // Tried adding weather but does not work
                    temperature.setText("21 °C");
//                    weatherIC.setText(Html.fromHtml(jsonData[6]));

                }
            });

            recommendButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openSnack();
                }
            });
            trendingButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openTrending();
                }
            });
            lunchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openLunch();
                }
            });
            dinnerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openDinner();
                }
            });
            saveData();
        }

    }
    public String[] getJSONResponse() {
        String[] jsonData = new String[2];
        JSONObject jsonWeather = null;
        try {
            jsonWeather = getWeatherJSON(latitude, longtitude);
        } catch (Exception e) {
            Log.d("Error", "Cannot process JSON results", e);
        }
        try {
            if(jsonWeather != null) {
                JSONObject details = jsonWeather.getJSONArray("weather").getJSONObject(0);
                JSONObject main = jsonWeather.getJSONObject("main");
                DateFormat df = DateFormat.getDateInstance();

//                String city = jsonWeather.getString("name");
                String temperature = String.format("%.of", main.getDouble("temp")) + "°";
//                String iconText = setWeatherIcon(details.getInt("id"), jsonWeather.getJSONObject("sys").getLong("sunrise")*1000,
//                        jsonWeather.getJSONObject("sys").getLong("sunset")*1000);
                jsonData[1] = temperature;
//                jsonData[2] = iconText;
            }
        } catch (Exception e) {

        }
        return jsonData;
    }

    public static String setWeatherIcon(int actualID, long sunrise, long sunset) {
        int id = actualID / 100;
        String icon = "";
        if (actualID == 800){
            long currentTime = new Date().getTime();
            if(currentTime >= sunrise && currentTime < sunset) {
                icon = "&#xf00d;";
            } else {
                icon = "&#xf02e";
            }
        } else {
            switch (id) {
                case 2:
                    icon = "&#xf01e;";
                    break;
                case 3:
                    icon = "&#xf01c;";
                    break;
                case 7:
                    icon = "&#xf014;";
                    break;
                case 8:
                    icon = "&#xf013;";
                    break;
                case 6:
                    icon = "&#xf01b;";
                    break;
                case 5:
                    icon = "&#xf019;";
                    break;
            }
        }
        return icon;
    }

    public static  JSONObject getWeatherJSON(String lat, String lon) {
        try{
            URL url = new URL(String.format(OPEN_WEATHER_MAP_URL, lat, lon));
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.addRequestProperty("x-api-key", OPEN_WEATHER_MAP_API);
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuffer json = new StringBuffer(1024);
            String tmp = "";
            while((tmp = reader.readLine())!= null) {
                json.append(tmp).append("\n");
            }
            reader.close();
            JSONObject data = new JSONObject(json.toString());
            if(data.getInt("cod") != 200) {
                return null;
            }
            return data;
        }catch (Exception e){
            return null;
        }
    }
    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, 1);
    }

    public void openSnack() {
        Intent intent = new Intent(this, Snack.class);
        startActivity(intent);
    }
    public void openTrending() {
        Intent intent = new Intent(this, Trending.class);
        startActivity(intent);
    }
    public void openLunch() {
        Intent intent = new Intent(this, Lunch.class);
        startActivity(intent);
    }
    public void openDinner() {
        Intent intent = new Intent(this, Dinner.class);
        startActivity(intent);
    }

    private void showSetup() {
        Intent intent = new Intent(this, FirstTimePreferences.class);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("firstStart", false);
        editor.apply();
        startActivity(intent);
    }

    public void saveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETOPDONE, done);
        editor.putString(NAMEUSER, username);
        editor.apply();
    }

    public void loadData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        done = sharedPreferences.getBoolean(SETOPDONE, false);
        username = sharedPreferences.getString(NAMEUSER, "");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (done) {
            BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
            bottomNavigationView.setSelectedItemId(R.id.nav_home);
        } else {
            loadData();
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}