package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FirstTimePreferences extends AppCompatActivity {
    private Button doneButton;
    private EditText enterName;
    private EditText enterAge;
    private EditText enterWeight;
    private EditText enterHeight;

    private TextView textName;
    private TextView textAge;
    private TextView textWeight;
    private TextView textHeight;

    public boolean done = false;
    private String name = "";
    private int age = 0;
    private float weight = 0;
    private float height = 0;


    public static final String SETOPDONE = "setupDone";
    public static final String AGEUSER = "ageUser";
    public static final String NAMEUSER = "nameUser";
    public static final String HEIGHTUSER = "heightUser";
    public static final String WEIGHTUSER = "weightUser";
    public static final String EXTRA_TEXT = "com.example.application.test.EXTRA_TEXT";
    public static final String REDCOLOUR = "#FF0000";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_time_preferences);

        enterName = (EditText) findViewById(R.id.edittext_entername);
        enterAge = (EditText) findViewById(R.id.edittext_enterage);
        enterWeight = (EditText) findViewById(R.id.edittext_enterweight);
        enterHeight = (EditText) findViewById(R.id.edittext_enterheight);

        textName = (TextView) findViewById(R.id.text_entername);
        textAge = (TextView) findViewById(R.id.text_enterage);
        textHeight = (TextView) findViewById(R.id.text_enterheight);
        textWeight = (TextView) findViewById(R.id.text_enterweight);

        doneButton = (Button) findViewById(R.id.button_done_setup);

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String extraName = enterName.getText().toString();
                String extraAge = enterAge.getText().toString();
                String extraWeight = enterWeight.getText().toString();
                String extraHeight = enterHeight.getText().toString();

                if (extraName.matches("")) {
                    textName.setTextColor(Color.parseColor(REDCOLOUR));
                } else if (!extraName.matches("")){
                    name  = enterName.getText().toString();
                }
                if (extraAge.matches("")) {
                    textAge.setTextColor(Color.parseColor(REDCOLOUR));
                } else if (!extraAge.matches("")) {
                    age = Integer.parseInt(enterAge.getText().toString());
                }
                if (extraHeight.matches("")) {
                    textHeight.setTextColor(Color.parseColor(REDCOLOUR));
                } else if (!extraHeight.matches("")) {
                    height = Float.parseFloat(enterHeight.getText().toString());
                }
                if (extraWeight.matches("")) {
                    textWeight.setTextColor(Color.parseColor(REDCOLOUR));
                } else if (!extraWeight.matches("")) {
                    weight = Float.parseFloat(enterWeight.getText().toString());
                }

                if (!extraName.matches("") && !extraAge.matches("") && !extraHeight.matches("") && !extraWeight.matches("")) {
                    check();
                } else {
                    showMessage();
                }
            }
        });
    }

    public void check() {
        Pattern namePattern = Pattern.compile("^(?=.{2,20}$)(?![_.])(?!.*[_.]{2})[a-zA-Z0-9._]+(?<![_.])$", Pattern.CASE_INSENSITIVE);
        Pattern agePattern = Pattern.compile("^[1-9][3-9]$|^[2-9]\\d$", Pattern.CASE_INSENSITIVE);
        Pattern heightPattern = Pattern.compile("^(([1-2])(\\.\\d\\d?)?)$|^(([0-2])(\\.[0-9][1-9]?)?)$", Pattern.CASE_INSENSITIVE);
        Pattern decimalPattern = Pattern.compile("^-?[0-9][0-9,\\.]+$", Pattern.CASE_INSENSITIVE);

        Matcher matcherName = namePattern.matcher(name);
        Matcher matcherAge = agePattern.matcher(Integer.toString(age));
        Matcher matcherWeight = decimalPattern.matcher(Float.toString(weight));
        Matcher matcherHeight = heightPattern.matcher(Float.toString(height));
        boolean matchNameFound = matcherName.find();
        boolean matchAgeFound = matcherAge.find();
        boolean matchWeightFound = matcherWeight.find();
        boolean matchHeightFound = matcherHeight.find();
        if(!matchNameFound) {
            showNameMessage();
        } else if(!matchAgeFound) {
            showAgeMessage();
        } else if(!matchWeightFound) {
            showWeightMessage();
        } else if(!matchHeightFound) {
            showHeightMessage();
        } else if(!matchNameFound && !matchAgeFound && !matchWeightFound && !matchHeightFound) {
            showMessage();
        } else {
            done = true;
            saveData();
            openMainPage();
        }
        if (!matchNameFound) {
            textName.setTextColor(Color.parseColor(REDCOLOUR));
        }
        if (!matchAgeFound) {
            textAge.setTextColor(Color.parseColor(REDCOLOUR));
        }
        if (!matchHeightFound) {
            textHeight.setTextColor(Color.parseColor(REDCOLOUR));
        }
        if (!matchWeightFound) {
            textWeight.setTextColor(Color.parseColor(REDCOLOUR));
        }
    }

    public void openMainPage() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void saveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETOPDONE, done);
        editor.putString(NAMEUSER, enterName.getText().toString());
        editor.putInt(AGEUSER, Integer.parseInt(enterAge.getText().toString()));
        editor.putFloat(HEIGHTUSER, Float.parseFloat((enterHeight.getText().toString())));
        editor.putFloat(WEIGHTUSER, Float.parseFloat(enterWeight.getText().toString()));
        editor.apply();
    }

    public void showNameMessage() {
        Toast.makeText(this, "Please enter a correct name", Toast.LENGTH_SHORT).show();
    }

    public void showAgeMessage() {
        Toast.makeText(this, "Please enter your age as a number, between 13 and 99", Toast.LENGTH_SHORT).show();
    }

    public void showWeightMessage() {
        Toast.makeText(this, "Please enter your weight as a number or decimal", Toast.LENGTH_SHORT).show();
    }

    public void showHeightMessage() {
        Toast.makeText(this, "Please enter your height as a number or decimal, between 0.01 and 2.99", Toast.LENGTH_SHORT).show();
    }
    public void showMessage() {
        Toast.makeText(this, "Please fill in the details correctly", Toast.LENGTH_SHORT).show();
    }
}