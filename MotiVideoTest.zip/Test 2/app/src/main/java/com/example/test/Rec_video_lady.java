package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;


public class Rec_video_lady extends AppCompatActivity {
    VideoView videoLadyVideoView;
    Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rec_video_man);

        videoLadyVideoView = (VideoView) findViewById(R.id.video_view_man);

        uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.fitnesslady);
        videoLadyVideoView.setVideoURI(uri);


        videoLadyVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                showThumbnail(mediaPlayer);
            }
        });

        Button button = findViewById(R.id.btn_play_man);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoLadyVideoView.start();
            }
        });
    }

    private void showThumbnail(MediaPlayer mediaPlayer) {
        mediaPlayer.start();;
        mediaPlayer.pause();
        mediaPlayer.seekTo(0);

    }

}
