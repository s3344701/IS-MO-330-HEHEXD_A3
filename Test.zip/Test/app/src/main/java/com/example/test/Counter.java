package com.example.test;

public class Counter {
    private int weightValue;
    private int fatValue;
    private int carbValue;
    private int proteinValue;
    private int calorieValue;
}
